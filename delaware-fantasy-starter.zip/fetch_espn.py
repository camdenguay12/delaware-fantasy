"""Fetch public ESPN fantasy football league data and append projection snapshots."""
import json,os,datetime,urllib.request,pathlib
BASE=pathlib.Path(__file__).parent/'data';BASE.mkdir(exist_ok=True)
LEAGUE=int(os.getenv('ESPN_LEAGUE_ID','562354279'));YEAR=int(os.getenv('ESPN_SEASON','2026'))
URL=f'https://lm-api-reads.fantasy.espn.com/apis/v3/games/ffl/seasons/{YEAR}/segments/0/leagues/{LEAGUE}'
def fetch(views,**params):
 from urllib.parse import urlencode
 query=urlencode([('view',v) for v in views]+list(params.items()))
 req=urllib.request.Request(URL+'?'+query,headers={'User-Agent':'Mozilla/5.0 (compatible; DelawareFantasyDashboard/1.0)','Accept':'application/json'})
 with urllib.request.urlopen(req,timeout=30) as r:return json.load(r)
def read(name,default):
 try:return json.loads((BASE/name).read_text())
 except (OSError,ValueError):return default
def write(name,data):
 (BASE/name).write_text(json.dumps(data,indent=2,ensure_ascii=False)+'\n')
def main():
 basic=fetch(['mTeam','mStandings','mScoreboard','mStatus','mMatchupScore'])
 week=int(basic.get('scoringPeriodId') or basic.get('status',{}).get('currentMatchupPeriod') or 1)
 # Period-scoped request is necessary for correct weekly score and live projections.
 weekly=fetch(['mMatchupScore','mBoxscore'],matchupPeriodId=week,scoringPeriodId=week)
 teams=[]
 for t in basic.get('teams',[]):
  rec=t.get('record',{}).get('overall',{});name=t.get('name') or (' '.join(filter(None,[t.get('location'),t.get('nickname')]))) or f'Team {t["id"]}'
  teams.append({'id':t['id'],'name':name,'logo':t.get('logo') or '', 'rank':t.get('playoffSeed') or t.get('rankCalculatedFinal') or t.get('divisionStanding'), 'pointsFor':rec.get('pointsFor',0),'record':{'wins':rec.get('wins',0),'losses':rec.get('losses',0),'ties':rec.get('ties',0)}})
 # Ranking by actual W/L and points scored when no reliable overall rank is available.
 teams.sort(key=lambda t:(-t['record']['wins'],t['record']['losses'],-t['pointsFor']))
 for i,t in enumerate(teams):t['rank']=i+1
 matchups=[];history=read('history.json',{});now=datetime.datetime.now(datetime.timezone.utc).isoformat()
 for m in weekly.get('schedule',[]):
  if int(m.get('matchupPeriodId',-1))!=week or not m.get('home') or not m.get('away'):continue
  sides=[]
  for side in ['home','away']:
   s=m[side];sides.append({'id':s['teamId'],'score':s.get('totalPoints',0),'projected':s.get('totalProjectedPointsLive',s.get('totalPoints',0))})
  mid=str(m.get('id',f'{week}-{sides[0]["id"]}-{sides[1]["id"]}'))
  matchups.append({'id':mid,'home':sides[0],'away':sides[1],'winner':m.get('winner','UNDECIDED')})
  if any('totalProjectedPointsLive' in m[s] for s in ['home','away']):
   points=history.setdefault(mid,[])
   if not points or now[:16]!=points[-1]['at'][:16]:points.append({'at':now,'home':sides[0]['projected'],'away':sides[1]['projected']})
   history[mid]=points[-3000:]
 if not teams:raise RuntimeError('ESPN response contained no teams; refusing to overwrite valid data')
 write('league.json',{'leagueId':LEAGUE,'season':YEAR,'week':week,'updatedAt':now,'teams':teams,'matchups':matchups})
 write('history.json',history)
 print(f'Updated week {week}: {len(teams)} teams, {len(matchups)} matchups')
if __name__=='__main__':main()
