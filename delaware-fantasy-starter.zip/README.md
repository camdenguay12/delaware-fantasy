# Delaware Fantasy

A public ESPN fantasy football dashboard for league **562354279**, 2026 season.

## Features
- Orange, cream, lavender sports-themed responsive dashboard with Delaware football emblem
- Weekly matchup cards and standings sidebar
- Detailed matchup selector, standings, projections, and historical projection chart
- Commissioner rankings page, prepared for future Google Docs integration
- Weekly completed-matchup results
- GitHub Actions ESPN data refresh every 15 minutes (best effort; scheduling can be delayed)
- Browser checks for updated JSON every 60 seconds; not a real-time streaming feed

## Launch
1. Create a **public** GitHub repository named `delaware-fantasy`.
2. Upload the **contents** of this folder, including `.github/workflows/sync.yml` and `.nojekyll`, to the repository's default branch.
3. In GitHub, open **Actions → ESPN Live Data Sync → Run workflow**. Check logs. If ESPN returns 401/403, the league may not be accessible from GitHub Actions despite its public setting; investigate before adding authentication.
4. In **Settings → Pages**, set **Deploy from a branch**, branch `main`, folder `/ (root)`.
5. Visit `https://YOUR-USERNAME.github.io/delaware-fantasy/` after Pages deploys.

## Data
ESPN's unofficial v3 endpoints are subject to change. The workflow writes `data/league.json` and appends `data/history.json`. It intentionally fails rather than publishing fabricated data when ESPN is unavailable. ESPN's current projected score may be missing; the interface displays only data provided by the feed. No win probabilities are invented; they remain unavailable until a calibrated probability model is implemented.

`data/rankings.json` is an empty array until commissioner rankings are provided. Future rows can follow this schema:

```json
[{"week":7,"rank":1,"previousRank":2,"teamId":3,"writeup":"Commissioner's weekly analysis."}]
```

To add Google Docs syncing, provide the document URL and decide whether to publish its content publicly. Do not store private Google credentials in this public repository.

## Caveats
The standing order is based on wins, losses, then points scored; custom ESPN tiebreakers or division rules may differ. Projection history starts at first successful workflow run and cannot recreate past snapshots. GitHub scheduled workflows can be delayed or disabled after inactivity. ESPN data requests may be throttled or rejected.
